DROP SEQUENCE IF EXISTS points_id_seq CASCADE;
SELECT DropGeometryTable('points');
