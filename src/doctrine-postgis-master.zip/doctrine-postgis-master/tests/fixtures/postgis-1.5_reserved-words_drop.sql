DROP SEQUENCE IF EXISTS user_id_seq CASCADE;
SELECT DropGeometryTable('user');
